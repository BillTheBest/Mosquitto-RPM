var group__service =
[
    [ "lws_cancel_service", "group__service.html#ga53e3d0801dfda7960a7249dd559e68a2", null ],
    [ "lws_cancel_service_pt", "group__service.html#ga29c246707997ab7a466aa709aecd2d7b", null ],
    [ "lws_plat_service_tsi", "group__service.html#gab1ff2c19455268fa0d5b617d8057fbfc", null ],
    [ "lws_service", "group__service.html#gaf95bd0c663d6516a0c80047d9b1167a8", null ],
    [ "lws_service_adjust_timeout", "group__service.html#ga4fd9d714434ca499e2b3f7dbba86f241", null ],
    [ "lws_service_fd", "group__service.html#gad82efa5466d14a9f05aa06416375b28d", null ],
    [ "lws_service_fd_tsi", "group__service.html#gaebf426eda371ba23642fc11d8e0ace6b", null ],
    [ "lws_service_tsi", "group__service.html#ga9b3cc4473fd8848e5bbee7f310712939", null ]
];