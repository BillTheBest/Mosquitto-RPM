var structlws__pollfd =
[
    [ "events", "structlws__pollfd.html#ac393db6fc7fb6ed8fe7ca20936908ee9", null ],
    [ "fd", "structlws__pollfd.html#a714cf5ca90b41926117fdde9fa6542be", null ],
    [ "revents", "structlws__pollfd.html#ae7cecfe7511c59d4a3a44f876d030932", null ]
];