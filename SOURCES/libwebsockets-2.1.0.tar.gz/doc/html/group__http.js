var group__http =
[
    [ "Form Parsing", "group__form-parsing.html", "group__form-parsing" ],
    [ "HTML Chunked Substitution", "group__html-chunked-substitution.html", "group__html-chunked-substitution" ],
    [ "HTTP File transfer", "group__httpft.html", "group__httpft" ],
    [ "HTTP headers: create", "group__HTTP-headers-create.html", "group__HTTP-headers-create" ],
    [ "HTTP headers: read", "group__HTTP-headers-read.html", "group__HTTP-headers-read" ],
    [ "Urlencode and Urldecode", "group__urlendec.html", "group__urlendec" ],
    [ "lws_tokens", "structlws__tokens.html", [
      [ "token", "structlws__tokens.html#a9f3635412bc71a5cb78e9862b55f10cd", null ],
      [ "token_len", "structlws__tokens.html#a855b7375d1d58516c0ecd4b60e9a7766", null ]
    ] ],
    [ "lws_http_redirect", "group__http.html#ga8fbf01e473ac421fc33ad9f8da8b8a25", null ],
    [ "lws_http_transaction_completed", "group__http.html#gad27aed6c66a41b2b89ffe4da2a309e8a", null ],
    [ "lws_return_http_status", "group__http.html#gac8a4a71240857dc6b2ed70456b6923f4", null ]
];